const KEY="htd_phone_v1";
const data={
 contacts:[
  {id:"thien-dat",name:"Hoắc Thiên Dật",initial:"霍",desc:"Người đặc biệt"},
  {id:"luc-tram",name:"Lục Trầm",initial:"陆",desc:"Bạn bè"},
  {id:"a-nguyet",name:"A Nguyệt",initial:"月",desc:"Bạn thân"}
 ],
 songs:[
  {title:"Mộng Giang Nam",artist:"Hoắc Thiên Dật"},
  {title:"Dạ Vũ",artist:"Tịch Nguyệt"},
  {title:"Phong Hoa",artist:"Vô Danh"}
 ],
 posts:[
  {id:1,user:"Hoắc Thiên Dật",text:"Hôm nay trời rất đẹp.",likes:12,comments:["Cảnh đẹp thật.","Đúng vậy."]},
  {id:2,user:"A Nguyệt",text:"Có người nào đó lại mất ngủ.",likes:8,comments:["Ai thế?"]}
 ]
};
let state=JSON.parse(localStorage.getItem(KEY)||'null')||{
 page:"home",chat:null,song:0,
 chats:{},diary:[],posts:data.posts.map(x=>({...x,comments:[...x.comments]}))
};
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
const $=s=>document.querySelector(s);
const esc=s=>String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
function setPage(p){state.page=p;save();render()}
function render(){
 $("#date").textContent=new Date().toLocaleDateString("vi-VN",{weekday:"long",day:"2-digit",month:"2-digit",year:"numeric"});
 document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===state.page));
 const a=$("#app");
 if(state.page==="home")a.innerHTML=home();
 if(state.page==="messages")a.innerHTML=messages();
 if(state.page==="chat")a.innerHTML=chat();
 if(state.page==="contacts")a.innerHTML=contacts();
 if(state.page==="diary")a.innerHTML=diary();
 if(state.page==="weibo")a.innerHTML=weibo();
}
function home(){return `<h2>Xin chào ♡</h2><div class="grid">
<div class="card" onclick="setPage('messages')"><div class="icon">💬</div><div class="title">Tin nhắn</div><div class="sub">Những cuộc trò chuyện</div></div>
<div class="card" onclick="setPage('contacts')"><div class="icon">♧</div><div class="title">Danh bạ</div><div class="sub">${data.contacts.length} liên hệ</div></div>
<div class="card wide" onclick="music()"><div class="icon">🎵</div><div class="title">Đang phát · ${esc(data.songs[state.song].title)}</div><div class="sub">${esc(data.songs[state.song].artist)} · chạm để đổi bài</div></div>
<div class="card" onclick="setPage('diary')"><div class="icon">📖</div><div class="title">Nhật ký</div><div class="sub">${state.diary.length} ghi chép</div></div>
<div class="card" onclick="setPage('weibo')"><div class="icon">◉</div><div class="title">Weibo</div><div class="sub">Bài đăng & tương tác</div></div>
</div>`}
function messages(){return `<button class="back" onclick="setPage('home')">‹ Trang chủ</button><h2>Tin nhắn</h2><div class="list">${data.contacts.map(c=>`<div class="item" onclick="openChat('${c.id}')"><div class="avatar">${c.initial}</div><div class="grow"><b>${esc(c.name)}</b><div class="sub">${esc(lastMsg(c.id)||c.desc)}</div></div>›</div>`).join("")}</div>`}
function lastMsg(id){let x=state.chats[id];return x&&x.length?x[x.length-1].text:""}
function openChat(id){state.chat=id;state.page="chat";save();render()}
function chat(){let c=data.contacts.find(x=>x.id===state.chat), msgs=state.chats[state.chat]||[];return `<button class="back" onclick="setPage('messages')">‹ Tin nhắn</button><h2>${esc(c.name)}</h2><div>${msgs.length?msgs.map(m=>`<div class="bubble ${m.me?'mine':'theirs'}">${esc(m.text)}</div>`).join(""):`<div class="empty">Chưa có tin nhắn</div>`}</div><div class="inputrow"><input id="chatInput" placeholder="Viết tin nhắn..." onkeydown="if(event.key==='Enter')sendChat()"><button class="btn" onclick="sendChat()">Gửi</button></div>`}
function sendChat(){let i=$("#chatInput"),t=i.value.trim();if(!t)return;(state.chats[state.chat]??=[]).push({text:t,me:true,time:Date.now()});save();render();setTimeout(()=>{let replies=["Ừ, mình nghe đây.","Được, để mình nhớ nhé.","Cậu cứ nói đi.","Mình đã đọc rồi."];(state.chats[state.chat]??=[]).push({text:replies[Math.floor(Math.random()*replies.length)],me:false,time:Date.now()});save();render()},500)}
function contacts(){return `<button class="back" onclick="setPage('home')">‹ Trang chủ</button><h2>Danh bạ</h2><div class="list">${data.contacts.map(c=>`<div class="item" onclick="openChat('${c.id}')"><div class="avatar">${c.initial}</div><div class="grow"><b>${esc(c.name)}</b><div class="sub">${esc(c.desc)}</div></div><span>♡</span></div>`).join("")}</div>`}
function music(){state.song=(state.song+1)%data.songs.length;save();render()}
function diary(){return `<button class="back" onclick="setPage('home')">‹ Trang chủ</button><h2>Nhật ký</h2><div class="inputrow"><input id="diaryInput" placeholder="Viết một dòng cho hôm nay..." onkeydown="if(event.key==='Enter')addDiary()"><button class="btn" onclick="addDiary()">Lưu</button></div><div>${state.diary.slice().reverse().map(n=>`<div class="note"><b>${esc(n.date)}</b><div>${esc(n.text)}</div></div>`).join("")||`<div class="empty">Nhật ký còn trống.</div>`}</div>`}
function addDiary(){let i=$("#diaryInput"),t=i.value.trim();if(!t)return;state.diary.push({date:new Date().toLocaleString("vi-VN"),text:t});save();render()}
function weibo(){return `<button class="back" onclick="setPage('home')">‹ Trang chủ</button><h2>Weibo</h2><div class="inputrow"><input id="postInput" placeholder="Bạn đang nghĩ gì?"><button class="btn" onclick="addPost()">Đăng</button></div><div style="margin-top:15px">${state.posts.map(p=>`<article class="post"><b>${esc(p.user)}</b><p>${esc(p.text)}</p><div class="actions"><button class="linkbtn" onclick="likePost(${p.id})">♡ ${p.likes}</button><button class="linkbtn" onclick="commentPost(${p.id})">💬 ${p.comments.length}</button><button class="linkbtn" onclick="sharePost(${p.id})">↗ Chia sẻ</button></div>${p.comments.map(c=>`<div class="sub">• ${esc(c)}</div>`).join("")}</article>`).join("")}</div>`}
function addPost(){let i=$("#postInput"),t=i.value.trim();if(!t)return;state.posts.unshift({id:Date.now(),user:"Bạn",text:t,likes:0,comments:[]});save();render()}
function likePost(id){let p=state.posts.find(x=>x.id===id);if(p)p.likes++;save();render()}
function commentPost(id){let t=prompt("Viết bình luận:");if(!t?.trim())return;let p=state.posts.find(x=>x.id===id);p.comments.push(t.trim());save();render()}
function sharePost(id){let p=state.posts.find(x=>x.id===id);if(p){state.posts.unshift({...p,id:Date.now(),user:"Bạn · repost",text:"↗ "+p.text});save();render()}}
document.querySelectorAll(".nav button").forEach(b=>b.onclick=()=>setPage(b.dataset.page));
render();