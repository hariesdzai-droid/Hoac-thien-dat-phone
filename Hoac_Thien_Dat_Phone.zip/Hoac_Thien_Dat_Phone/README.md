# Hoắc Thiên Dật — Virtual Phone

Bản demo web app giao diện điện thoại ảo.

## Chạy thử
Mở `index.html` bằng trình duyệt.

## Đưa vào Google AI Studio
Có thể đưa toàn bộ repository lên GitHub rồi dùng Build Mode → Import from GitHub.

## Tính năng
- Tin nhắn nhiều người, lịch sử lưu trong localStorage
- Danh bạ
- Đổi bài nhạc
- Nhật ký
- Weibo: đăng bài, thích, bình luận, repost
- Giao diện responsive cho điện thoại

Đây là bản nền để tiếp tục mở rộng bằng AI Studio.
